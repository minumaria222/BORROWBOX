# BorrowBox – Java Student Item Sharing

Java 21 + Spring Boot + Spring Data JPA + MySQL. The browser interface is HTML/CSS/JavaScript served by the Java Spring Boot application.

## Run
1. Install JDK 21, Maven 3.9+, and MySQL 8+.
2. In MySQL run: `CREATE DATABASE borrowbox_db;`
3. Set `DB_USERNAME` and `DB_PASSWORD` environment variables if your MySQL credentials differ from root/blank.
4. Open this folder in VS Code. Install Extension Pack for Java.
5. Run `mvn spring-boot:run`.
6. Visit http://localhost:8080.

The database tables are created/updated by JPA. For a quick demo, create students with `POST /api/users`, create listings with `POST /api/items`, then submit borrow requests with `POST /api/requests`.

## API demo
Create student: POST `/api/users`, JSON `{"name":"Asha","email":"asha@college.edu","department":"CSE"}`.
Create item: POST `/api/items`, header `X-User-Id: 1`, JSON `{"name":"Scientific Calculator","category":"Calculators","description":"Good condition","conditionLabel":"Good","location":"CSE","maxDays":7}`.
Request: POST `/api/requests`, header `X-User-Id: 2`, JSON `{"itemId":"1","startDate":"2026-11-10","endDate":"2026-11-12","message":"Needed for lab"}`.

## Important
This is an educational starter, not production-ready authentication. The `X-User-Id` header is a demo identity mechanism. Add Spring Security login, password hashing, role checks and CSRF protection before deployment. The UI prompts for student IDs to keep the starter easy to test.
