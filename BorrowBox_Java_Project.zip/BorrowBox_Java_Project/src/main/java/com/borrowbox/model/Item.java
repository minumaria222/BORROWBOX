package com.borrowbox.model;
import jakarta.persistence.*;
@Entity @Table(name="items")
public class Item {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String name;
 @Column(nullable=false) private String category;
 @Column(length=1200) private String description;
 private String conditionLabel, location, imageUrl;
 private Integer maxDays=7;
 private boolean available=true;
 @ManyToOne(optional=false) private Student owner;
 public Item() {}
 public Long getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;}
 public String getCategory(){return category;} public void setCategory(String v){category=v;}
 public String getDescription(){return description;} public void setDescription(String v){description=v;}
 public String getConditionLabel(){return conditionLabel;} public void setConditionLabel(String v){conditionLabel=v;}
 public String getLocation(){return location;} public void setLocation(String v){location=v;}
 public String getImageUrl(){return imageUrl;} public void setImageUrl(String v){imageUrl=v;}
 public Integer getMaxDays(){return maxDays;} public void setMaxDays(Integer v){maxDays=v;}
 public boolean isAvailable(){return available;} public void setAvailable(boolean v){available=v;}
 public Student getOwner(){return owner;} public void setOwner(Student v){owner=v;}
}