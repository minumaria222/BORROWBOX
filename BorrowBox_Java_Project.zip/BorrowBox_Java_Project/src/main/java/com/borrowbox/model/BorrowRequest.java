package com.borrowbox.model;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity @Table(name="borrow_requests")
public class BorrowRequest {
 public enum Status { PENDING, APPROVED, REJECTED, CANCELLED, RETURNED }
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private Item item;
 @ManyToOne(optional=false) private Student borrower, owner;
 private LocalDate startDate,endDate;
 @Column(length=600) private String message;
 @Enumerated(EnumType.STRING) private Status status=Status.PENDING;
 public BorrowRequest() {}
 public Long getId(){return id;} public Item getItem(){return item;} public void setItem(Item v){item=v;}
 public Student getBorrower(){return borrower;} public void setBorrower(Student v){borrower=v;}
 public Student getOwner(){return owner;} public void setOwner(Student v){owner=v;}
 public LocalDate getStartDate(){return startDate;} public void setStartDate(LocalDate v){startDate=v;}
 public LocalDate getEndDate(){return endDate;} public void setEndDate(LocalDate v){endDate=v;}
 public String getMessage(){return message;} public void setMessage(String v){message=v;}
 public Status getStatus(){return status;} public void setStatus(Status v){status=v;}
}