package com.borrowbox.repository;
import com.borrowbox.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ItemRepository extends JpaRepository<Item,Long> {
 List<Item> findByAvailableTrue();
 List<Item> findByAvailableTrueAndCategoryIgnoreCase(String category);
 List<Item> findByAvailableTrueAndNameContainingIgnoreCase(String search);
}