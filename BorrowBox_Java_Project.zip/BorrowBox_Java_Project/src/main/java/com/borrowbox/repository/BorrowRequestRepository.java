package com.borrowbox.repository;
import com.borrowbox.model.BorrowRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface BorrowRequestRepository extends JpaRepository<BorrowRequest,Long> {
 List<BorrowRequest> findByBorrowerId(Long id);
 List<BorrowRequest> findByOwnerId(Long id);
}