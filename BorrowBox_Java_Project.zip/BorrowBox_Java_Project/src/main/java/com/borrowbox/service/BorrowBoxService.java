package com.borrowbox.service;
import com.borrowbox.model.*;
import com.borrowbox.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
@Service
public class BorrowBoxService {
 private final StudentRepository students; private final ItemRepository items; private final BorrowRequestRepository requests;
 public BorrowBoxService(StudentRepository s,ItemRepository i,BorrowRequestRepository r){students=s;items=i;requests=r;}
 public List<Item> browse(String category,String search){
  if(search!=null&&!search.isBlank()) return items.findByAvailableTrueAndNameContainingIgnoreCase(search);
  if(category!=null&&!category.isBlank()) return items.findByAvailableTrueAndCategoryIgnoreCase(category);
  return items.findByAvailableTrue();
 }
 public Item addItem(Long ownerId,Item item){
  Student owner=students.findById(ownerId).orElseThrow(()->new IllegalArgumentException("Student not found"));
  item.setOwner(owner); item.setAvailable(true); return items.save(item);
 }
 @Transactional public BorrowRequest request(Long borrowerId,Long itemId,LocalDate start,LocalDate end,String message){
  if(start==null||end==null||!end.isAfter(start)||start.isBefore(LocalDate.now())) throw new IllegalArgumentException("Choose valid future dates.");
  Student borrower=students.findById(borrowerId).orElseThrow(()->new IllegalArgumentException("Student not found"));
  Item item=items.findById(itemId).orElseThrow(()->new IllegalArgumentException("Item not found"));
  if(!item.isAvailable()) throw new IllegalArgumentException("Item is unavailable.");
  if(item.getOwner().getId().equals(borrowerId)) throw new IllegalArgumentException("You cannot borrow your own item.");
  if(item.getMaxDays()!=null&&end.isAfter(start.plusDays(item.getMaxDays()))) throw new IllegalArgumentException("Borrowing period exceeds owner limit.");
  BorrowRequest r=new BorrowRequest();r.setItem(item);r.setBorrower(borrower);r.setOwner(item.getOwner());r.setStartDate(start);r.setEndDate(end);r.setMessage(message);return requests.save(r);
 }
 public List<BorrowRequest> mine(Long id){return requests.findByBorrowerId(id);}
 public List<BorrowRequest> received(Long id){return requests.findByOwnerId(id);}
 @Transactional public BorrowRequest decide(Long ownerId,Long requestId,boolean approve){
  BorrowRequest r=requests.findById(requestId).orElseThrow(()->new IllegalArgumentException("Request not found"));
  if(!r.getOwner().getId().equals(ownerId))throw new IllegalArgumentException("Only the owner can decide.");
  if(r.getStatus()!=BorrowRequest.Status.PENDING)throw new IllegalArgumentException("Request is not pending.");
  if(approve){if(!r.getItem().isAvailable())throw new IllegalArgumentException("Item unavailable.");r.setStatus(BorrowRequest.Status.APPROVED);r.getItem().setAvailable(false);items.save(r.getItem());}
  else r.setStatus(BorrowRequest.Status.REJECTED);
  return requests.save(r);
 }
 @Transactional public BorrowRequest returned(Long ownerId,Long requestId){
  BorrowRequest r=requests.findById(requestId).orElseThrow(()->new IllegalArgumentException("Request not found"));
  if(!r.getOwner().getId().equals(ownerId))throw new IllegalArgumentException("Only the owner can mark returned.");
  if(r.getStatus()!=BorrowRequest.Status.APPROVED)throw new IllegalArgumentException("Only approved requests can be returned.");
  r.setStatus(BorrowRequest.Status.RETURNED);r.getItem().setAvailable(true);items.save(r.getItem());return requests.save(r);
 }
}