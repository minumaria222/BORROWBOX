package com.borrowbox.controller;
import com.borrowbox.model.*;
import com.borrowbox.repository.StudentRepository;
import com.borrowbox.service.BorrowBoxService;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.*;
@RestController @RequestMapping("/api")
public class ApiController {
 private final BorrowBoxService service; private final StudentRepository students;
 public ApiController(BorrowBoxService s,StudentRepository st){service=s;students=st;}
 @PostMapping("/students") public Student student(@RequestBody Student s){return students.save(s);}
 @GetMapping("/students") public List<Student> students(){return students.findAll();}
 @GetMapping("/items") public List<Item> items(@RequestParam(required=false)String category,@RequestParam(required=false)String search){return service.browse(category,search);}
 @PostMapping("/items") public Item add(@RequestHeader("X-User-Id")Long uid,@RequestBody Item item){return service.addItem(uid,item);}
 @PostMapping("/requests") public BorrowRequest request(@RequestHeader("X-User-Id")Long uid,@RequestBody Map<String,String>b){return service.request(uid,Long.valueOf(b.get("itemId")),LocalDate.parse(b.get("startDate")),LocalDate.parse(b.get("endDate")),b.get("message"));}
 @GetMapping("/requests/mine") public List<BorrowRequest> mine(@RequestHeader("X-User-Id")Long uid){return service.mine(uid);}
 @GetMapping("/requests/received") public List<BorrowRequest> received(@RequestHeader("X-User-Id")Long uid){return service.received(uid);}
 @PutMapping("/requests/{requestId}/approve") public BorrowRequest approve(@RequestHeader("X-User-Id")Long uid,@PathVariable Long requestId){return service.decide(uid,requestId,true);}
 @PutMapping("/requests/{requestId}/reject") public BorrowRequest reject(@RequestHeader("X-User-Id")Long uid,@PathVariable Long requestId){return service.decide(uid,requestId,false);}
 @PutMapping("/requests/{requestId}/return") public BorrowRequest returned(@RequestHeader("X-User-Id")Long uid,@PathVariable Long requestId){return service.returned(uid,requestId);}
}
